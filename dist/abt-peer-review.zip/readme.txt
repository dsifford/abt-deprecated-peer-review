=== Academic Blogger's Toolkit - Depreciated Peer Review Extension ===
Contributors: dsifford
Donate link: https://cash.me/$dsifford
Tags: academic, pmid, doi, peer-review, pubmed, citation, bibliography, reference
Requires at least: 4.2.2
Tested up to: 4.6
Stable tag: 3.4.3
License: GPL3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html
