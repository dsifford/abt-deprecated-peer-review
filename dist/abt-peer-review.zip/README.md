# This repository is unmaintained. Use at your own risk.

### Installation
1. Download the `.zip` file in the `dist` directory.
2. Navigate to `Plugins` in your wordpress installation and click `Add New`
3. Click `Upload Plugin`.
4. Upload the `.zip` file from step 1.
